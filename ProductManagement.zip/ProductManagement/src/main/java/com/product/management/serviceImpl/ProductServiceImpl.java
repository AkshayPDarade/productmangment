package com.product.management.serviceImpl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.product.management.model.Product;
import com.product.management.repositoy.ProductRepository;
import com.product.management.service.ProductService;

@Service
public class ProductServiceImpl implements ProductService{
	
	@Autowired
	ProductRepository productRepository;

	@Override
	public Product saveProduct(Product product) {
		return productRepository.save(product);
	}

	@Override
	public List<Product> getAllProduct() {
		return productRepository.findAll();
	}

	@Override
	public Product getProductById(Integer id) {
		// TODO Auto-generated method stub
		return productRepository.findById(id).get();
	}

	@Override
	public String deleteProduct(Integer id) {
		this.productRepository.deleteById(id);
		return "product delete successfully";

}

	@Override
	public Product editProduct(Product product, Integer id) {
		
		Product products=productRepository.findById(id).get();
		
		products.setDesription(product.getDesription());
		products.setProductName(product.getProductName());
		products.setPrice(product.getPrice());
		products.setStatus(product.getStatus());
		return productRepository.save(products);
	}
	
}
